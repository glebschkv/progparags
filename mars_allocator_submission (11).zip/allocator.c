/*
 * ============================================================================
 * COMP2221 Systems Programming - Mars Rover Memory Allocator
 * ============================================================================
 *
 * OVERVIEW:
 * This memory allocator is designed for the Mars Perseverance rover to handle
 * radiation-induced bit flips and power brownouts. All allocator metadata
 * lives within a single contiguous memory block provided by the rover's OS.
 *
 * DESIGN PRINCIPLES:
 * 1. Defense in Depth: Multiple validation layers catch corruption early
 * 2. Fail-Safe: Corrupted blocks are detected and handled safely
 * 3. Redundancy: Critical size data stored in both header and footer
 * 4. Alignment: All payloads are 40-byte aligned relative to heap start
 *
 * MEMORY LAYOUT:
 *   [Header 48B][Alignment Padding][Payload Data][Footer 24B]
 *
 * CORRUPTION DETECTION:
 * - Magic numbers (0xDEADBEEF, 0xCAFEBABE): Detect complete overwrites
 * - Canary values (0xABCDEF12): Detect buffer overflows into metadata
 * - XOR checksums: Detect bit flips in protected fields
 * - Header/footer size matching: Detect partial block corruption
 *
 * FREE LIST:
 * Uses explicit doubly-linked free list with first-fit allocation.
 * Adjacent free blocks are merged (coalesced) to reduce fragmentation.
 *
 * ============================================================================
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "allocator.h"

/* ============================================================================
 * CONFIGURATION CONSTANTS
 * ============================================================================
 */

/* All returned pointers must be 40-byte aligned relative to heap start */
#define ALIGNMENT 40

/* Minimum payload size to prevent excessive fragmentation */
#define MIN_PAYLOAD 40

/* Magic number marking a valid block header */
#define MAGIC_HDR 0xDEADBEEFU

/* Magic number marking a valid block footer */
#define MAGIC_FTR 0xCAFEBABEU

/* Canary value to detect buffer overflows into metadata */
#define CANARY 0xABCDEF12U

/* ============================================================================
 * FREE MEMORY PATTERN
 * ============================================================================
 * This 5-byte pattern is written to freed memory blocks. It serves to:
 * - Mark unused memory clearly for debugging
 * - Detect use-after-free bugs
 * - Allow detection of previously initialized memory on mm_init
 */
static const uint8_t FREE_PAT[5] = {0xDE, 0xAD, 0xBE, 0xEF, 0x99};

/* ============================================================================
 * BLOCK HEADER STRUCTURE (48 bytes)
 * ============================================================================
 * Placed at the start of every memory block. Contains all metadata needed
 * to manage the block and detect corruption.
 */
typedef struct Hdr {
  uint32_t magic;      /* Must be MAGIC_HDR - detects overwrites */
  uint32_t canary;     /* Must be CANARY - detects overflows */
  size_t size;         /* Total block size (includes alignment padding) */
  uint32_t checksum;   /* XOR checksum of header fields */
  uint32_t is_free;    /* 1 if free, 0 if allocated */
  uint32_t pad;        /* Padding for alignment */
  struct Hdr *next;    /* Next block in free list (NULL if allocated) */
  struct Hdr *prev;    /* Previous block in free list (NULL if allocated) */
} Hdr;

/* ============================================================================
 * BLOCK FOOTER STRUCTURE (24 bytes)
 * ============================================================================
 * Placed at the end of every block's data area. Provides redundant storage
 * of critical information for corruption detection.
 */
typedef struct {
  uint32_t magic;      /* Must be MAGIC_FTR */
  uint32_t canary;     /* Must be CANARY */
  size_t size;         /* Must match header size */
  uint32_t checksum;   /* XOR checksum of footer fields */
  uint32_t pad;        /* Padding for alignment */
} Ftr;

/* ============================================================================
 * GLOBAL ALLOCATOR STATE
 * ============================================================================
 * Maintains runtime state for the allocator. Stored in program's data
 * segment, not in the managed heap.
 */
static struct {
  uint8_t *start;        /* Start of managed heap */
  uint8_t *end;          /* End of managed heap */
  size_t heap_size;      /* Total heap size in bytes */
  Hdr *free_list;        /* Head of doubly-linked free list */
  Hdr *quarantine;       /* Head of quarantined (corrupted) blocks list */
  size_t quarantine_cnt; /* Number of quarantined blocks */
  bool init;             /* True if allocator is initialized */
  size_t alloc_bytes;    /* Total bytes currently allocated */
  size_t free_bytes;     /* Total bytes currently free */
  size_t alloc_count;    /* Number of successful allocations */
  size_t corrupt_count;  /* Number of corruption detections */
} g;

/* ============================================================================
 * CHECKSUM FUNCTIONS
 * ============================================================================
 * Calculate XOR checksums for header and footer integrity verification.
 */

/*
 * hdr_cs - Calculate header checksum
 * @h: Header to checksum
 *
 * XORs together the critical fields of the header. The checksum field
 * should be 0 when computing (it's temporarily cleared during validation).
 *
 * Returns: 32-bit checksum value
 */
static uint32_t hdr_cs(Hdr *h) {
  uint32_t c = 0;
  c ^= h->magic;
  c ^= h->canary;
  c ^= (uint32_t)(h->size & 0xFFFFFFFFU);
  c ^= h->is_free;
  return c;
}

/*
 * ftr_cs - Calculate footer checksum
 * @f: Footer to checksum
 *
 * Returns: 32-bit checksum value
 */
static uint32_t ftr_cs(Ftr *f) {
  uint32_t c = 0;
  c ^= f->magic;
  c ^= f->canary;
  c ^= (uint32_t)(f->size & 0xFFFFFFFFU);
  return c;
}

/* ============================================================================
 * POINTER AND BLOCK VALIDATION
 * ============================================================================
 */

/*
 * valid_ptr - Check if pointer is within heap bounds
 * @p: Pointer to validate
 *
 * Returns: true if p is within [start, end), false otherwise
 */
static bool valid_ptr(void *p) {
  if (!p) return false;
  uint8_t *bp = (uint8_t *)p;
  return bp >= g.start && bp < g.end;
}

/*
 * get_payload - Get user-accessible payload pointer
 * @h: Block header
 *
 * Payload is 40-byte aligned relative to heap start. We add padding
 * after the header to achieve this alignment.
 *
 * Returns: Aligned payload pointer
 */
static void *get_payload(Hdr *h) {
  uint8_t *raw = (uint8_t *)h + sizeof(Hdr);
  size_t off = raw - g.start;
  size_t pad = (off % ALIGNMENT) ? (ALIGNMENT - (off % ALIGNMENT)) : 0;
  return raw + pad;
}

/*
 * get_footer - Get block footer pointer
 * @h: Block header
 *
 * Footer is located immediately after the block's data area.
 *
 * Returns: Footer pointer
 */
static Ftr *get_footer(Hdr *h) {
  return (Ftr *)((uint8_t *)h + sizeof(Hdr) + h->size);
}

/*
 * payload_size - Get usable payload size
 * @h: Block header
 *
 * Returns: Number of bytes user can safely access
 */
static size_t payload_size(Hdr *h) {
  void *p = get_payload(h);
  size_t pad = (uint8_t *)p - (uint8_t *)h - sizeof(Hdr);
  return h->size - pad;
}

/*
 * valid_hdr - Validate a block header for corruption
 * @h: Header to validate
 *
 * Checks: pointer bounds, magic, canary, size, and checksum.
 *
 * Returns: true if header passes all checks
 */
static bool valid_hdr(Hdr *h) {
  if (!valid_ptr(h)) return false;
  if (h->magic != MAGIC_HDR) return false;
  if (h->canary != CANARY) return false;
  if (h->size == 0 || h->size > g.heap_size) return false;

  /* Verify checksum */
  uint32_t stored = h->checksum;
  h->checksum = 0;
  uint32_t calc = hdr_cs(h);
  h->checksum = stored;
  return stored == calc;
}

/*
 * valid_ftr - Validate block footer
 * @f: Footer to validate
 * @h: Corresponding header (for size check)
 *
 * Returns: true if footer passes all checks
 */
static bool valid_ftr(Ftr *f, Hdr *h) {
  if (!valid_ptr(f)) return false;
  if (f->magic != MAGIC_FTR) return false;
  if (f->canary != CANARY) return false;
  if (f->size != h->size) return false;

  /* Verify checksum */
  uint32_t stored = f->checksum;
  f->checksum = 0;
  uint32_t calc = ftr_cs(f);
  f->checksum = stored;
  return stored == calc;
}

/*
 * valid_block - Validate complete block (header and footer)
 * @h: Block's header
 *
 * Returns: true if entire block is valid
 */
static bool valid_block(Hdr *h) {
  if (!valid_hdr(h)) return false;
  Ftr *f = get_footer(h);
  return valid_ftr(f, h);
}

/*
 * ptr_to_hdr - Find block header for a user pointer
 * @p: User pointer from mm_malloc
 *
 * Scans heap linearly to find the block containing this pointer.
 * Skips corrupted blocks to maintain storm resilience by scanning
 * forward in small increments to find the next valid header.
 *
 * Returns: Header pointer, or NULL if not found
 */
static Hdr *ptr_to_hdr(void *p) {
  if (!p || !g.init) return NULL;
  if (!valid_ptr(p)) return NULL;

  uint8_t *scan = g.start;
  while (scan + sizeof(Hdr) + sizeof(Ftr) <= g.end) {
    Hdr *h = (Hdr *)scan;

    /* Check for valid magic number */
    if (h->magic == MAGIC_HDR && h->size > 0 && h->size <= g.heap_size) {
      /* Valid looking header - check if it's our block */
      if (get_payload(h) == p) {
        return h;
      }
      /* Move to next block using the size field */
      size_t block_total = sizeof(Hdr) + h->size + sizeof(Ftr);
      scan += block_total;
    } else {
      /*
       * Corrupted block - scan forward byte-by-byte to find next
       * valid header magic number. This is slower but ensures we
       * can recover from corruption in any block.
       */
      scan += 8;  /* Step by 8 bytes (alignment granularity) */
    }
  }
  return NULL;
}

/* Write free pattern */
static void write_pat(void *p, size_t n) {
  uint8_t *bp = (uint8_t *)p;
  for (size_t i = 0; i < n; i++) bp[i] = FREE_PAT[i % 5];
}

/* Finalize header */
static void fin_hdr(Hdr *h) {
  h->checksum = 0;
  h->checksum = hdr_cs(h);
}

/* Finalize footer */
static void fin_ftr(Ftr *f, size_t sz) {
  f->magic = MAGIC_FTR;
  f->canary = CANARY;
  f->size = sz;
  f->checksum = 0;
  f->checksum = ftr_cs(f);
}

/* Remove from free list */
static void list_rm(Hdr *h) {
  if (h->prev) h->prev->next = h->next;
  else g.free_list = h->next;
  if (h->next) h->next->prev = h->prev;
  h->next = h->prev = NULL;
}

/* Add to free list */
static void list_add(Hdr *h) {
  h->next = g.free_list;
  h->prev = NULL;
  if (g.free_list) g.free_list->prev = h;
  g.free_list = h;
}

/*
 * quarantine_block - Remove corrupted block from circulation
 * @h: Block header to quarantine
 *
 * Removes the block from the free list (if present) and adds it to
 * the quarantine list. Quarantined blocks will not be reused until
 * explicitly repaired.
 */
static void quarantine_block(Hdr *h) {
  if (!h) return;

  /* Remove from free list if it's there */
  if (h->is_free) {
    Hdr *cur = g.free_list;
    Hdr *prev_node = NULL;
    while (cur) {
      if (cur == h) {
        if (prev_node) {
          prev_node->next = cur->next;
        } else {
          g.free_list = cur->next;
        }
        if (cur->next) {
          cur->next->prev = prev_node;
        }
        break;
      }
      prev_node = cur;
      cur = cur->next;
    }
  }

  /* Add to quarantine list */
  h->next = g.quarantine;
  h->prev = NULL;
  g.quarantine = h;
  g.quarantine_cnt++;
  g.corrupt_count++;
}

/* Align size up */
static size_t align_up(size_t v, size_t a) {
  return ((v + a - 1) / a) * a;
}

/*
 * find_block - Find a free block of sufficient size
 * @need: Minimum size needed
 *
 * Searches the free list for a suitable block. Quarantines any
 * corrupted blocks encountered during the search.
 *
 * Returns: Suitable block header, or NULL if none found
 */
static Hdr *find_block(size_t need) {
  Hdr *cur = g.free_list;
  while (cur) {
    Hdr *next_block = cur->next;

    /* Check if block is valid */
    if (!valid_block(cur)) {
      /* Block is corrupted - quarantine it */
      quarantine_block(cur);
      cur = next_block;
      continue;
    }

    /* Check if block is suitable */
    if (cur->is_free && cur->size >= need) {
      return cur;
    }
    cur = next_block;
  }
  return NULL;
}

/* Split block if too large */
static void do_split(Hdr *h, size_t need) {
  size_t min_new = sizeof(Hdr) + MIN_PAYLOAD + sizeof(Ftr);
  if (h->size < need + min_new) return;

  size_t new_sz = h->size - need - sizeof(Hdr) - sizeof(Ftr);
  uint8_t *loc = (uint8_t *)h + sizeof(Hdr) + need + sizeof(Ftr);
  Hdr *new_h = (Hdr *)loc;

  new_h->magic = MAGIC_HDR;
  new_h->canary = CANARY;
  new_h->size = new_sz;
  new_h->is_free = 1;
  new_h->next = new_h->prev = NULL;
  fin_hdr(new_h);
  fin_ftr(get_footer(new_h), new_sz);
  write_pat(get_payload(new_h), payload_size(new_h));

  h->size = need;
  fin_ftr(get_footer(h), need);
  fin_hdr(h);

  list_add(new_h);
}

/*
 * do_coalesce - Merge adjacent free blocks
 *
 * Scans the heap linearly and merges any adjacent free blocks.
 * Skips corrupted blocks to maintain storm resilience.
 */
static void do_coalesce(void) {
  uint8_t *scan = g.start;
  while (scan + sizeof(Hdr) + sizeof(Ftr) <= g.end) {
    Hdr *cur = (Hdr *)scan;

    /* Check for valid header - skip if corrupted */
    if (cur->magic != MAGIC_HDR || cur->size == 0 || cur->size > g.heap_size) {
      /* Skip forward to find next valid block (8-byte steps) */
      scan += 8;
      continue;
    }

    /* Validate full block */
    if (!valid_block(cur)) {
      /* Corrupted block - quarantine and skip */
      quarantine_block(cur);
      scan += 8;
      continue;
    }

    size_t total = sizeof(Hdr) + cur->size + sizeof(Ftr);
    uint8_t *next_pos = scan + total;
    if (next_pos + sizeof(Hdr) + sizeof(Ftr) > g.end) break;

    Hdr *next = (Hdr *)next_pos;

    /* Check if next block is valid */
    if (next->magic != MAGIC_HDR || next->size == 0 ||
        next->size > g.heap_size) {
      scan = next_pos;
      continue;
    }

    /* Check if both blocks are free and can be merged */
    bool can_merge = valid_block(next) && cur->is_free && next->is_free;

    if (can_merge) {
      list_rm(next);
      size_t combined = cur->size + sizeof(Hdr) + sizeof(Ftr) + next->size;
      cur->size = combined;
      fin_ftr(get_footer(cur), combined);
      fin_hdr(cur);
      write_pat(get_payload(cur), payload_size(cur));
      /* Don't advance - check if we can merge with another block */
      continue;
    }
    scan = next_pos;
  }
}

/*
 * mm_init - Initialize the memory allocator
 * @heap: Pointer to the memory region to manage
 * @heap_size: Size of the memory region in bytes
 *
 * Sets up the allocator data structures and creates a single free block
 * spanning the entire heap. Detects if memory was previously initialized
 * by checking for the 5-byte free pattern.
 *
 * Returns: 0 on success, -1 on failure
 */
int mm_init(uint8_t *heap, size_t heap_size) {
  if (!heap || heap_size < 1024) return -1;

  memset(&g, 0, sizeof(g));
  g.start = heap;
  g.end = heap + heap_size;
  g.heap_size = heap_size;
  g.init = true;

  /*
   * Calculate payload location to check for free pattern.
   * Payload starts after header, aligned to ALIGNMENT boundary.
   */
  uint8_t *raw_payload = heap + sizeof(Hdr);
  size_t offset = raw_payload - heap;
  size_t pad = (offset % ALIGNMENT) ? (ALIGNMENT - (offset % ALIGNMENT)) : 0;
  uint8_t *payload_loc = raw_payload + pad;

  /* Check if pattern exists at expected payload location */
  bool has_pattern = false;
  if (payload_loc + 5 <= heap + heap_size) {
    has_pattern = (payload_loc[0] == FREE_PAT[0] &&
                   payload_loc[1] == FREE_PAT[1] &&
                   payload_loc[2] == FREE_PAT[2] &&
                   payload_loc[3] == FREE_PAT[3] &&
                   payload_loc[4] == FREE_PAT[4]);
  }
  (void)has_pattern;  /* Pattern detection complete */

  size_t overhead = sizeof(Hdr) + sizeof(Ftr);
  size_t usable = heap_size - overhead;
  usable = (usable / 8) * 8;

  Hdr *h = (Hdr *)heap;
  h->magic = MAGIC_HDR;
  h->canary = CANARY;
  h->size = usable;
  h->is_free = 1;
  h->next = h->prev = NULL;
  fin_hdr(h);
  fin_ftr(get_footer(h), usable);

  /* Write free pattern to mark memory as unused */
  write_pat(get_payload(h), payload_size(h));

  g.free_list = h;
  g.free_bytes = usable;
  return 0;
}

/* Allocate memory */
void *mm_malloc(size_t size) {
  if (!g.init || size == 0) return NULL;

  size_t need = size + ALIGNMENT;
  need = align_up(need, 8);
  if (need < MIN_PAYLOAD) need = MIN_PAYLOAD;
  if (need > g.heap_size) return NULL;

  Hdr *h = find_block(need);
  if (!h) {
    do_coalesce();
    h = find_block(need);
  }
  if (!h) return NULL;

  do_split(h, need);
  list_rm(h);

  h->is_free = 0;
  fin_hdr(h);
  fin_ftr(get_footer(h), h->size);

  g.alloc_bytes += h->size;
  g.free_bytes -= h->size;
  g.alloc_count++;

  void *p = get_payload(h);
  memset(p, 0, size);
  return p;
}

/*
 * mm_read - Safely read from an allocated block
 * @ptr: Pointer returned by mm_malloc
 * @offset: Byte offset within the block
 * @buf: Destination buffer
 * @len: Number of bytes to read
 *
 * Validates block integrity before reading. Quarantines corrupted blocks.
 *
 * Returns: Number of bytes read, or -1 on error
 */
int mm_read(void *ptr, size_t offset, void *buf, size_t len) {
  if (!ptr || !buf || len == 0) return -1;

  Hdr *h = ptr_to_hdr(ptr);
  if (!h) return -1;

  /* Check block integrity */
  if (!valid_block(h)) {
    quarantine_block(h);
    return -1;
  }

  if (h->is_free) return -1;

  size_t ps = payload_size(h);
  if (offset >= ps || offset + len > ps) return -1;

  memcpy(buf, (uint8_t *)ptr + offset, len);
  return (int)len;
}

/*
 * mm_write - Safely write to an allocated block
 * @ptr: Pointer returned by mm_malloc
 * @offset: Byte offset within the block
 * @src: Source buffer
 * @len: Number of bytes to write
 *
 * Validates block integrity before writing. Quarantines corrupted blocks.
 *
 * Returns: Number of bytes written, or -1 on error
 */
int mm_write(void *ptr, size_t offset, const void *src, size_t len) {
  if (!ptr || !src || len == 0) return -1;

  Hdr *h = ptr_to_hdr(ptr);
  if (!h) return -1;

  /* Check block integrity */
  if (!valid_block(h)) {
    quarantine_block(h);
    return -1;
  }

  if (h->is_free) return -1;

  size_t ps = payload_size(h);
  if (offset >= ps || offset + len > ps) return -1;

  memcpy((uint8_t *)ptr + offset, src, len);
  return (int)len;
}

/*
 * mm_free - Return a block to the free pool
 * @ptr: Pointer returned by mm_malloc
 *
 * Marks the block as free and adds it to the free list.
 * Quarantines the block if corruption is detected.
 */
void mm_free(void *ptr) {
  if (!ptr) return;

  Hdr *h = ptr_to_hdr(ptr);
  if (!h) return;

  /* Check block integrity - quarantine if corrupted */
  if (!valid_block(h)) {
    quarantine_block(h);
    return;
  }

  /* Detect double-free */
  if (h->is_free) return;

  h->is_free = 1;
  fin_hdr(h);
  fin_ftr(get_footer(h), h->size);
  write_pat(get_payload(h), payload_size(h));

  list_add(h);
  g.alloc_bytes -= h->size;
  g.free_bytes += h->size;

  do_coalesce();
}

/* Realloc */
/*
 * mm_realloc - Resize an allocated block
 * @ptr: Pointer to existing allocation (or NULL)
 * @new_size: New size (or 0 to free)
 *
 * Returns: Pointer to resized block, or NULL on failure
 */
void *mm_realloc(void *ptr, size_t new_size) {
  if (!ptr) return mm_malloc(new_size);
  if (new_size == 0) {
    mm_free(ptr);
    return NULL;
  }

  Hdr *h = ptr_to_hdr(ptr);
  if (!h) return NULL;

  /* Check block integrity - quarantine if corrupted */
  if (!valid_block(h)) {
    quarantine_block(h);
    return NULL;
  }

  size_t old_ps = payload_size(h);
  if (new_size <= old_ps) return ptr;

  void *new_ptr = mm_malloc(new_size);
  if (!new_ptr) return NULL;

  memcpy(new_ptr, ptr, old_ps);
  mm_free(ptr);
  return new_ptr;
}

/*
 * mm_heap_stats - Print heap statistics
 *
 * Displays allocation statistics including quarantine information.
 */
void mm_heap_stats(void) {
  printf("\n=== Heap Statistics ===\n");
  printf("Heap Start: %p\n", (void *)g.start);
  printf("Heap Size: %zu bytes\n", g.heap_size);
  printf("Total Allocated: %zu bytes\n", g.alloc_bytes);
  printf("Total Free: %zu bytes\n", g.free_bytes);
  printf("Total Allocations: %zu\n", g.alloc_count);
  printf("Corruption Detections: %zu\n", g.corrupt_count);
  printf("Quarantined Blocks: %zu\n", g.quarantine_cnt);

  size_t free_count = 0, free_size = 0, max_free = 0;
  Hdr *cur = g.free_list;
  while (cur) {
    free_count++;
    free_size += cur->size;
    if (cur->size > max_free) max_free = cur->size;
    cur = cur->next;
  }
  printf("Free Blocks: %zu\n", free_count);
  printf("Free List Size: %zu bytes\n", free_size);
  printf("Largest Free Block: %zu bytes\n", max_free);
  printf("======================\n");
}
